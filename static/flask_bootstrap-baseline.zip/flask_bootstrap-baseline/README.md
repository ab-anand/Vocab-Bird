# flask_bootstrap
A simple HOWTO that demos how to pass Bootstrap attributes to Flask-WTF.
